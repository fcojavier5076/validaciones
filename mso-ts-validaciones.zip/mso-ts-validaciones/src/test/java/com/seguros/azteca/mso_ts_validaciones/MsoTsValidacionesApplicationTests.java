package com.seguros.azteca.mso_ts_validaciones;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MsoTsValidacionesApplicationTests {

	@Test
	void contextLoads() {
	}

}
