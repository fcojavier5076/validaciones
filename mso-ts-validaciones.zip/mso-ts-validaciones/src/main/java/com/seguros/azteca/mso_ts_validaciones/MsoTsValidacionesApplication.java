package com.seguros.azteca.mso_ts_validaciones;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MsoTsValidacionesApplication {

	public static void main(String[] args) {
		SpringApplication.run(MsoTsValidacionesApplication.class, args);
	}

}
